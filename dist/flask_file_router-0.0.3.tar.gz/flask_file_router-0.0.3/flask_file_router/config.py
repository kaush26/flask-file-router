default_config = {
    "root_dir": "./home",
    "default_index": "__main__.py",
    "ext_exclude_list": ["pyc"],
    "ext_include_list": ["py"],
}
